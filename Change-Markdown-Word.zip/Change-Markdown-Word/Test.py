#!/usr/bin/env python
# -*- coding: UTF-8 -*-
"""
@Project ：PythonScript 
@File    ：test.py
@Author  ：金脚大王
@Date    ：2024/1/29 15:46 
@脚本说明：
"""
import os
print(os.getenv("PORT"))