## 一、部署sqllabs靶场环境

### 1、任务清单

需要完成的任务

-  打开``Vmware``中的``Centos-1``虚拟机
-  使用``MobaXtermSSH``连接``Centos-1``虚拟机
-  开启``Centos-1``虚拟机的``Lampp``服务
-  使用``Firefox``浏览器打开`Centos-``1`上的``Sqllabs``靶场

### 2、批处理脚本代码

#### (1)、Batch代码

```shell
REM 启动虚拟机
start "" "D:\Program Files (x86)\VMware\VMware Workstation\vmware.exe" -x "D:\Users\Ito futaba\Documents\Virtual Machines\CentOS 7-1\CentOS 7-1.vmx"

REM 等待虚拟机启动完成
timeout /t 50

REM 测试虚拟机是否能够被网络访问
ping 192.168.225.60 -n 1 -w 5000 > nul

REM 连接虚拟机并执行命令
start ""  "D:\Program Files (x86)\Mobatek\MobaXterm\MobaXterm.exe" -exec "ssh root@192.168.225.60 '/opt/lampp/lampp start'"

REM 等待lampp服务启动完成
timeout /t 7

REM 使用火狐浏览器打开sqllabs网址
"C:\Program Files\Mozilla Firefox\firefox.exe" -url "http://192.168.225.60/sqllabs"
```

#### (2)、代码解析

-  需要使用异步来执行启动虚拟机软件，打开`MobaXterm`软件等任务，因为在执行这些可执行程序时，会卡在对应行代码无法向下继续执行。使用``start``来执行异步操作，随后使用`timeout`来等待程序执行完毕所需的时间，可以解决这个问题。但是缺点就是因为性能的问题这个时间可能有长有短，为了确保脚本正常运行我们只好预留更长的时间 
-  使用`ping`命令来检查虚拟机是否已经成功启动，并且网络连接可用，为后续使用`MobaXterm`连接提供预先检查

## 附、专业术语

### 1、REM

``REM`` 的全称是 "`Remark`"，它是 "`Windows` `Command` `Prompt`"（`Windows` 命令提示符）和批处理文件中用于添加注释和备注的命令。通过使用 ``REM`` 命令，可以在批处理文件中添加额外的说明和信息，以帮助人们理解和维护该文件。

### 2、Timeout

`timeout`是`Windows`命令行中用于暂停执行的命令，`/``t`参数指定要等待的时间（以秒为单位），默认为 `30` 秒。例如，执行以下命令将暂停执行 `5` 秒钟：

```
Copy Codetimeout /t 5
```

在等待的时间到期后，命令行窗口将继续执行。这个命令通常用于在脚本中暂停执行一段时间，或者用于等待某些进程完成。

### 3、Start

#### (1)、异步后台执行

要在 `cmd` 中异步执行一个可执行程序并传递参数，可以使用 ``start`` 命令加上 ``/B`` 参数。下面是一个示例：

```
Copy Codestart /B "" "C:\path\to\program.exe" arg1 arg2 arg3
```

在上述示例中，`start` `/B` 命令以后台模式启动指定路径下的 ``program.exe`` 可执行文件，并传递了三个参数 ``arg1``、``arg2`` 和 ``arg3``。

请注意，程序路径和参数需要根据实际情况进行替换，确保路径正确并且传递的参数与程序期望的参数一致。

使用 ``start` `/B`` 命令可以让程序在后台运行，同时允许批处理文件继续向下执行其他命令，而不会被该命令阻塞

#### (2)、标题参数

在使用 ``start`` 命令时，双引号用于包含标题参数。如果 ``start`` 命令没有标题参数，将会默认使用第一个参数作为标题，这可能导致一些问题，如参数包含空格时无法正确解析等。

为了避免这些问题，可以使用一个空的双引号作为标题参数，来确保 ``start`` 命令正确地解析其他参数。例如：

```
Copy Codestart "" "C:\path\to\program.exe" arg1 arg2
```

在上面的示例中，``start`` 命令使用一个空的双引号作为标题参数，以便正确解析后面的参数 ``arg1`` 和 ``arg2``。

因此，空的双引号在 ``start`` 命令中被视为必需的，即使您不需要为启动的进程指定标题。

### 4、Ping

``ping` `-n``是``ping``命令的一个参数，用于指定要发送的 `ICMP` 请求数据包数目。

具体来说，``-n``后面跟着一个数字，表示要发送的 `ICMP` 请求数据包数目。例如：

```
Copy Codeping -n 5 www.google.com
```

这个命令会向``www.google.com``发送`5`个 `ICMP` 请求数据包，并等待对方返回相应的响应数据包。

在上面提到的脚本中，``ping``命令的作用是等待虚拟机网络连接就绪。``-n` `1``表示只发送一个 `ICMP` 请求数据包，``-w` `5000``表示等待`5`秒钟。这样，如果在`5`秒钟内能够成功收到虚拟机的响应数据包，就表示网络连接已经就绪，可以继续执行后续的操作了。如果超过了`5`秒钟仍然没有收到响应数据包，就会超时而退出。